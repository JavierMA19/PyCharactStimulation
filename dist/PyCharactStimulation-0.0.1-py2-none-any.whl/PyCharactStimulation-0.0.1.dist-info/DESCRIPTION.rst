Library for electrodes stimulation tools                   


